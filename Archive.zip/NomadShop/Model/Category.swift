//
//  Category.swift
//  NomadShop
//
//  Created by Aldiyar Massimkhanov on 7/21/20.
//  Copyright © 2020 Aldiyaar. All rights reserved.
//

import Foundation
import UIKit

struct Category {
    var title: String
    var image: UIImage

}
